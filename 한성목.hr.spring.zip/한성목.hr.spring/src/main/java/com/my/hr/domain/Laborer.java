package com.my.hr.domain;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class Laborer {
	private int laborerId;
	private String laborerName;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate hireDate;
}
